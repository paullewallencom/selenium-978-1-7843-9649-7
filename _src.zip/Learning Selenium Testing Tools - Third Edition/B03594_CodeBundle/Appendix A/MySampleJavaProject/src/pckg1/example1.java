package pckg1;

public class example1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("I have done with my 1st program on java");	
		// method1("Test");
	}
	static void method1 (String str){
		System.out.println(str);		
	}
}