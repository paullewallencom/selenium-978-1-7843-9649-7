package MyFirstPackage;

public class IfCondition {
	public static void main(String[] args) {
		int empSal = 20000;
		if (empSal >= 10000) {
			System.out.println("he is a manager...!");
		}
		else 
		{
			System.out.println("he is NOT a manager...!");
		}
	}
}