package MyFirstPackage;

public class Narrowingandwdining {

	public static void main(String[] args) {
		float i = 10 ;
		int j  ;
		
			System.out.println(i);
		
		//double j = 20.89;
		
		 i =  (float) 20.89;
		 System.out.println(i);
		 
		 j = (int) i;
		 System.out.println(j);
	}
}